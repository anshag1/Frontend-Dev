CSS Practice Project
---------------------
Open index.html in VS Code or your browser. Each question has its own folder (q1..q10) with an HTML and CSS file.
No JavaScript or external frameworks are used.
