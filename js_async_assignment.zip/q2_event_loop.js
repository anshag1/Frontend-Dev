// Q2 – Micro vs Macro Task
console.log("Start");

setTimeout(() => console.log("Macrotask: setTimeout"), 0);

Promise.resolve().then(() =>
  console.log("Microtask: Promise.then")
);

console.log("Synchronous Log");
console.log("End");

// Microtasks (Promises) run before macrotasks (setTimeout)
// because JS event loop prioritizes microtask queue.
